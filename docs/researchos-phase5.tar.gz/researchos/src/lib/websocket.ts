import type { AnyWSEvent, EventType, WSEventMap } from "@/types/websocket";

const BASE_WS_URL =
  process.env.NEXT_PUBLIC_WS_URL ??
  process.env.NEXT_PUBLIC_API_URL?.replace(/^http/, "ws") ??
  "ws://localhost:8000";

const RECONNECT_BASE_MS = 1_000;
const RECONNECT_MAX_MS = 30_000;
const RECONNECT_MAX_ATTEMPTS = 10;
const PING_INTERVAL_MS = 25_000;

type EventHandler<T extends EventType> = (event: WSEventMap[T]) => void;
type AnyHandler = (event: AnyWSEvent) => void;

type ListenerMap = {
  [K in EventType]?: Set<EventHandler<K>>;
};

export type ConnectionState =
  | "connecting"
  | "connected"
  | "reconnecting"
  | "disconnected";

export interface WSClientOptions {
  projectId: string;
  token: string;
  onStateChange?: (state: ConnectionState) => void;
  onError?: (error: Event) => void;
}

export class ResearchWSClient {
  private ws: WebSocket | null = null;
  private listeners: ListenerMap = {};
  private catchAllListeners: Set<AnyHandler> = new Set();
  private reconnectAttempts = 0;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private pingTimer: ReturnType<typeof setInterval> | null = null;
  private state: ConnectionState = "disconnected";
  private destroyed = false;

  private readonly projectId: string;
  private readonly token: string;
  private readonly onStateChange?: (state: ConnectionState) => void;
  private readonly onError?: (error: Event) => void;

  constructor(opts: WSClientOptions) {
    this.projectId = opts.projectId;
    this.token = opts.token;
    this.onStateChange = opts.onStateChange;
    this.onError = opts.onError;
  }

  connect(): void {
    if (this.destroyed) return;
    if (
      this.ws?.readyState === WebSocket.OPEN ||
      this.ws?.readyState === WebSocket.CONNECTING
    ) {
      return;
    }
    this._setState(
      this.reconnectAttempts === 0 ? "connecting" : "reconnecting"
    );
    const url = `${BASE_WS_URL}/api/v1/ws/projects/${this.projectId}?token=${encodeURIComponent(this.token)}`;
    this.ws = new WebSocket(url);
    this.ws.onopen = this._handleOpen;
    this.ws.onmessage = this._handleMessage;
    this.ws.onclose = this._handleClose;
    this.ws.onerror = this._handleError;
  }

  disconnect(): void {
    this.destroyed = true;
    this._clearTimers();
    if (this.ws) {
      this.ws.onopen = null;
      this.ws.onmessage = null;
      this.ws.onclose = null;
      this.ws.onerror = null;
      if (
        this.ws.readyState === WebSocket.OPEN ||
        this.ws.readyState === WebSocket.CONNECTING
      ) {
        this.ws.close(1000, "Client disconnecting");
      }
      this.ws = null;
    }
    this._setState("disconnected");
  }

  on<T extends EventType>(type: T, handler: EventHandler<T>): () => void {
    if (!this.listeners[type]) {
      (this.listeners as Record<string, Set<unknown>>)[type] = new Set();
    }
    (this.listeners[type] as Set<EventHandler<T>>).add(handler);
    return () => this.off(type, handler);
  }

  off<T extends EventType>(type: T, handler: EventHandler<T>): void {
    (this.listeners[type] as Set<EventHandler<T>> | undefined)?.delete(handler);
  }

  onAny(handler: AnyHandler): () => void {
    this.catchAllListeners.add(handler);
    return () => this.catchAllListeners.delete(handler);
  }

  send(payload: Record<string, unknown>): void {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(payload));
    }
  }

  getState(): ConnectionState {
    return this.state;
  }

  private _handleOpen = (): void => {
    this.reconnectAttempts = 0;
    this._setState("connected");
    this._startPing();
  };

  private _handleMessage = (event: MessageEvent): void => {
    let parsed: AnyWSEvent;
    try {
      parsed = JSON.parse(event.data as string) as AnyWSEvent;
    } catch {
      return;
    }
    const type = parsed.event_type as EventType;
    if (type === "ping") {
      this.send({ event_type: "pong", project_id: this.projectId });
      return;
    }
    const handlers = this.listeners[type] as Set<AnyHandler> | undefined;
    handlers?.forEach((h) => h(parsed));
    this.catchAllListeners.forEach((h) => h(parsed));
  };

  private _handleClose = (event: CloseEvent): void => {
    this._clearTimers();
    if (this.destroyed || event.code === 1000) {
      this._setState("disconnected");
      return;
    }
    this._scheduleReconnect();
  };

  private _handleError = (event: Event): void => {
    this.onError?.(event);
  };

  private _scheduleReconnect(): void {
    if (this.destroyed) return;
    if (this.reconnectAttempts >= RECONNECT_MAX_ATTEMPTS) {
      this._setState("disconnected");
      return;
    }
    const delay = Math.min(
      RECONNECT_BASE_MS * Math.pow(2, this.reconnectAttempts),
      RECONNECT_MAX_MS
    );
    this.reconnectAttempts += 1;
    this._setState("reconnecting");
    this.reconnectTimer = setTimeout(() => {
      this.connect();
    }, delay);
  }

  private _startPing(): void {
    this._clearPing();
    this.pingTimer = setInterval(() => {
      this.send({ event_type: "ping", project_id: this.projectId });
    }, PING_INTERVAL_MS);
  }

  private _clearPing(): void {
    if (this.pingTimer !== null) {
      clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
  }

  private _clearTimers(): void {
    this._clearPing();
    if (this.reconnectTimer !== null) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
  }

  private _setState(s: ConnectionState): void {
    if (this.state === s) return;
    this.state = s;
    this.onStateChange?.(s);
  }
}
