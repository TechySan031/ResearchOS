"use client";

import { create } from "zustand";
import { ResearchWSClient, type ConnectionState } from "@/lib/websocket";
import {
  EventType,
  type AnyWSEvent,
  type WorkflowProgressEvent,
  type AgentStartedEvent,
  type AgentCompletedEvent,
  type AgentFailedEvent,
  type WorkflowStartedEvent,
  type WorkflowCompletedEvent,
  type WorkflowFailedEvent,
  type DraftUpdatedEvent,
  type ArtifactCreatedEvent,
} from "@/types/websocket";

export type WorkflowStatus =
  | "idle"
  | "running"
  | "completed"
  | "failed";

export interface AgentState {
  name: string;
  description: string;
  index: number;
  total: number;
  status: "running" | "completed" | "failed";
  startedAt: string;
  completedAt?: string;
  durationSeconds?: number;
  tokensUsed?: number;
  outputSummary?: string;
  artifactsProduced?: string[];
  errorMessage?: string;
  retrying?: boolean;
}

export interface DraftSection {
  section_id: string;
  section_title: string;
  content: string;
  word_count: number;
  is_final: boolean;
}

interface WebSocketState {
  isConnected: boolean;
  connectionState: ConnectionState;
  projectId: string | null;
  currentAgent: AgentState | null;
  workflowStatus: WorkflowStatus;
  progress: number;
  progressMessage: string;
  completedAgents: number;
  totalAgents: number;
  draftSections: Record<string, DraftSection>;
  events: AnyWSEvent[];
  lastEvent: AnyWSEvent | null;
  error: string | null;
  connectionId: string | null;

  connect: (projectId: string, token: string) => void;
  disconnect: () => void;
  handleEvent: (event: AnyWSEvent) => void;
  clearEvents: () => void;
  clearError: () => void;
}

let _client: ResearchWSClient | null = null;

export const useWebSocketStore = create<WebSocketState>((set, get) => ({
  isConnected: false,
  connectionState: "disconnected",
  projectId: null,
  currentAgent: null,
  workflowStatus: "idle",
  progress: 0,
  progressMessage: "",
  completedAgents: 0,
  totalAgents: 0,
  draftSections: {},
  events: [],
  lastEvent: null,
  error: null,
  connectionId: null,

  connect: (projectId: string, token: string) => {
    const current = get();
    if (current.projectId === projectId && current.isConnected) return;

    if (_client) {
      _client.disconnect();
      _client = null;
    }

    set({
      projectId,
      workflowStatus: "idle",
      currentAgent: null,
      progress: 0,
      progressMessage: "",
      completedAgents: 0,
      totalAgents: 0,
      draftSections: {},
      events: [],
      lastEvent: null,
      error: null,
      connectionId: null,
    });

    _client = new ResearchWSClient({
      projectId,
      token,
      onStateChange: (state: ConnectionState) => {
        set({
          connectionState: state,
          isConnected: state === "connected",
        });
      },
      onError: () => {
        set({ error: "WebSocket connection error" });
      },
    });

    _client.onAny((event: AnyWSEvent) => {
      get().handleEvent(event);
    });

    _client.connect();
  },

  disconnect: () => {
    if (_client) {
      _client.disconnect();
      _client = null;
    }
    set({
      isConnected: false,
      connectionState: "disconnected",
      projectId: null,
      currentAgent: null,
      workflowStatus: "idle",
      progress: 0,
      progressMessage: "",
      completedAgents: 0,
      totalAgents: 0,
      draftSections: {},
      events: [],
      lastEvent: null,
      error: null,
      connectionId: null,
    });
  },

  handleEvent: (event: AnyWSEvent) => {
    set((state) => {
      const updatedEvents = [...state.events, event].slice(-500);

      switch (event.event_type) {
        case EventType.CONNECTION_ACK: {
          return {
            events: updatedEvents,
            lastEvent: event,
            connectionId: event.connection_id,
            error: null,
          };
        }

        case EventType.WORKFLOW_STARTED: {
          const e = event as WorkflowStartedEvent;
          return {
            events: updatedEvents,
            lastEvent: event,
            workflowStatus: "running" as WorkflowStatus,
            totalAgents: e.total_agents,
            completedAgents: 0,
            progress: 0,
            progressMessage: `Starting workflow: ${e.topic}`,
            currentAgent: null,
            error: null,
          };
        }

        case EventType.WORKFLOW_PROGRESS: {
          const e = event as WorkflowProgressEvent;
          return {
            events: updatedEvents,
            lastEvent: event,
            progress: e.percent_complete,
            progressMessage: e.message,
            completedAgents: e.completed_agents,
            totalAgents: e.total_agents,
            workflowStatus: "running" as WorkflowStatus,
          };
        }

        case EventType.WORKFLOW_COMPLETED: {
          const e = event as WorkflowCompletedEvent;
          return {
            events: updatedEvents,
            lastEvent: event,
            workflowStatus: "completed" as WorkflowStatus,
            progress: 100,
            progressMessage: `Completed in ${e.duration_seconds.toFixed(1)}s — ${e.papers_retrieved} papers, ${e.sections_generated} sections`,
            currentAgent: null,
          };
        }

        case EventType.WORKFLOW_FAILED: {
          const e = event as WorkflowFailedEvent;
          return {
            events: updatedEvents,
            lastEvent: event,
            workflowStatus: "failed" as WorkflowStatus,
            error: `Workflow failed at ${e.failed_agent}: ${e.error_message}`,
            currentAgent: null,
          };
        }

        case EventType.AGENT_STARTED: {
          const e = event as AgentStartedEvent;
          const newAgent: AgentState = {
            name: e.agent_name,
            description: e.agent_description,
            index: e.agent_index,
            total: e.total_agents,
            status: "running",
            startedAt: e.timestamp,
          };
          return {
            events: updatedEvents,
            lastEvent: event,
            currentAgent: newAgent,
            totalAgents: e.total_agents,
          };
        }

        case EventType.AGENT_COMPLETED: {
          const e = event as AgentCompletedEvent;
          const prev = state.currentAgent;
          const completed: AgentState = {
            name: e.agent_name,
            description: prev?.description ?? "",
            index: prev?.index ?? 0,
            total: prev?.total ?? state.totalAgents,
            status: "completed",
            startedAt: prev?.startedAt ?? e.timestamp,
            completedAt: e.timestamp,
            durationSeconds: e.duration_seconds,
            tokensUsed: e.tokens_used,
            outputSummary: e.output_summary,
            artifactsProduced: e.artifacts_produced,
          };
          return {
            events: updatedEvents,
            lastEvent: event,
            currentAgent: completed,
            completedAgents: state.completedAgents + 1,
          };
        }

        case EventType.AGENT_FAILED: {
          const e = event as AgentFailedEvent;
          const prev = state.currentAgent;
          const failed: AgentState = {
            name: e.agent_name,
            description: prev?.description ?? "",
            index: prev?.index ?? 0,
            total: prev?.total ?? state.totalAgents,
            status: "failed",
            startedAt: prev?.startedAt ?? e.timestamp,
            completedAt: e.timestamp,
            durationSeconds: e.duration_seconds,
            errorMessage: e.error_message,
            retrying: e.retrying,
          };
          return {
            events: updatedEvents,
            lastEvent: event,
            currentAgent: failed,
            error: e.retrying ? null : `Agent ${e.agent_name} failed: ${e.error_message}`,
          };
        }

        case EventType.DRAFT_UPDATED: {
          const e = event as DraftUpdatedEvent;
          const existing = state.draftSections[e.section_id];
          const updatedSection: DraftSection = {
            section_id: e.section_id,
            section_title: e.section_title,
            content: e.is_final
              ? e.content_chunk
              : (existing?.content ?? "") + e.content_chunk,
            word_count: e.word_count,
            is_final: e.is_final,
          };
          return {
            events: updatedEvents,
            lastEvent: event,
            draftSections: {
              ...state.draftSections,
              [e.section_id]: updatedSection,
            },
          };
        }

        case EventType.ARTIFACT_CREATED: {
          return {
            events: updatedEvents,
            lastEvent: event,
          };
        }

        case EventType.ERROR: {
          return {
            events: updatedEvents,
            lastEvent: event,
            error: event.message,
          };
        }

        case EventType.PING:
        case EventType.PONG:
          return { events: updatedEvents };

        default:
          return { events: updatedEvents, lastEvent: event };
      }
    });
  },

  clearEvents: () => set({ events: [], lastEvent: null }),

  clearError: () => set({ error: null }),
}));
