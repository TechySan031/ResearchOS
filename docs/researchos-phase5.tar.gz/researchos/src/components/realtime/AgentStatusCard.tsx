"use client";

import { useWebSocketStore } from "@/stores/websocketStore";
import type { AgentState } from "@/stores/websocketStore";
import { cn } from "@/lib/utils";
import {
  CheckCircle2,
  XCircle,
  Loader2,
  Cpu,
  Zap,
  Clock,
  RefreshCw,
  FileText,
} from "lucide-react";

function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds.toFixed(1)}s`;
  const m = Math.floor(seconds / 60);
  const s = (seconds % 60).toFixed(0).padStart(2, "0");
  return `${m}m ${s}s`;
}

function AgentStatusIcon({ status }: { status: AgentState["status"] }) {
  if (status === "completed")
    return <CheckCircle2 className="h-5 w-5 text-emerald-400" />;
  if (status === "failed") return <XCircle className="h-5 w-5 text-red-400" />;
  return (
    <Loader2 className="h-5 w-5 animate-spin text-indigo-400" />
  );
}

function AgentProgressRing({ index, total }: { index: number; total: number }) {
  const pct = total > 0 ? ((index + 1) / total) * 100 : 0;
  const r = 18;
  const circ = 2 * Math.PI * r;
  const dash = (pct / 100) * circ;

  return (
    <svg className="h-12 w-12 -rotate-90" viewBox="0 0 44 44">
      <circle
        cx="22"
        cy="22"
        r={r}
        fill="none"
        stroke="rgba(255,255,255,0.08)"
        strokeWidth="3"
      />
      <circle
        cx="22"
        cy="22"
        r={r}
        fill="none"
        stroke="rgb(99 102 241)"
        strokeWidth="3"
        strokeDasharray={`${dash} ${circ - dash}`}
        strokeLinecap="round"
        className="transition-all duration-700"
      />
      <text
        x="22"
        y="22"
        textAnchor="middle"
        dominantBaseline="central"
        className="rotate-90 text-[10px] font-mono fill-white/60"
        transform="rotate(90 22 22)"
      >
        {index + 1}/{total}
      </text>
    </svg>
  );
}

interface AgentStatusCardProps {
  className?: string;
}

export function AgentStatusCard({ className }: AgentStatusCardProps) {
  const currentAgent = useWebSocketStore((s) => s.currentAgent);
  const workflowStatus = useWebSocketStore((s) => s.workflowStatus);

  if (!currentAgent || workflowStatus === "idle") return null;

  const borderColor =
    currentAgent.status === "completed"
      ? "border-emerald-500/25"
      : currentAgent.status === "failed"
      ? "border-red-500/25"
      : "border-indigo-500/30";

  const headerBg =
    currentAgent.status === "completed"
      ? "bg-emerald-500/5"
      : currentAgent.status === "failed"
      ? "bg-red-500/5"
      : "bg-indigo-500/5";

  return (
    <div
      className={cn(
        "rounded-xl border overflow-hidden transition-all duration-300",
        borderColor,
        className
      )}
    >
      {/* Header */}
      <div
        className={cn(
          "flex items-center gap-3 px-4 py-3",
          headerBg
        )}
      >
        <AgentStatusIcon status={currentAgent.status} />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-white truncate">
            {currentAgent.name}
          </p>
          {currentAgent.description && (
            <p className="text-xs text-white/50 truncate">
              {currentAgent.description}
            </p>
          )}
        </div>
        <AgentProgressRing
          index={currentAgent.index}
          total={currentAgent.total}
        />
      </div>

      {/* Body */}
      <div className="px-4 py-3 space-y-3 bg-white/2">
        {/* Stats row */}
        <div className="grid grid-cols-3 gap-2">
          {currentAgent.durationSeconds !== undefined && (
            <StatChip
              icon={Clock}
              label="Duration"
              value={formatDuration(currentAgent.durationSeconds)}
            />
          )}
          {currentAgent.tokensUsed !== undefined && (
            <StatChip
              icon={Zap}
              label="Tokens"
              value={currentAgent.tokensUsed.toLocaleString()}
            />
          )}
          {currentAgent.artifactsProduced !== undefined && (
            <StatChip
              icon={FileText}
              label="Artifacts"
              value={String(currentAgent.artifactsProduced.length)}
            />
          )}
        </div>

        {/* Output summary */}
        {currentAgent.outputSummary && (
          <p className="text-xs text-white/60 leading-relaxed line-clamp-3">
            {currentAgent.outputSummary}
          </p>
        )}

        {/* Artifacts list */}
        {currentAgent.artifactsProduced &&
          currentAgent.artifactsProduced.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {currentAgent.artifactsProduced.map((a) => (
                <span
                  key={a}
                  className="px-2 py-0.5 rounded-full text-[10px] bg-indigo-500/10 text-indigo-300 border border-indigo-500/20"
                >
                  {a}
                </span>
              ))}
            </div>
          )}

        {/* Error */}
        {currentAgent.errorMessage && (
          <div className="rounded-lg bg-red-500/8 border border-red-500/20 px-3 py-2 flex items-start gap-2">
            <XCircle className="h-3.5 w-3.5 text-red-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="text-xs text-red-400 leading-relaxed">
                {currentAgent.errorMessage}
              </p>
              {currentAgent.retrying && (
                <p className="text-[10px] text-amber-400 flex items-center gap-1">
                  <RefreshCw className="h-2.5 w-2.5 animate-spin" />
                  Retrying…
                </p>
              )}
            </div>
          </div>
        )}

        {/* Running shimmer */}
        {currentAgent.status === "running" && (
          <div className="h-0.5 w-full rounded-full overflow-hidden bg-white/5">
            <div className="h-full w-1/3 rounded-full bg-indigo-500 animate-[progress_1.5s_ease-in-out_infinite]" />
          </div>
        )}
      </div>
    </div>
  );
}

function StatChip({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-lg bg-white/5 px-2.5 py-2 flex flex-col gap-0.5">
      <div className="flex items-center gap-1 text-white/30">
        <Icon className="h-2.5 w-2.5" />
        <span className="text-[9px] uppercase tracking-wider">{label}</span>
      </div>
      <span className="text-xs font-mono font-semibold text-white/80">
        {value}
      </span>
    </div>
  );
}
