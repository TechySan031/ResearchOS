"use client";

import { useEffect, useRef } from "react";
import { useWebSocketStore } from "@/stores/websocketStore";
import { EventType, type AnyWSEvent } from "@/types/websocket";
import { cn } from "@/lib/utils";
import {
  Play,
  CheckCircle2,
  XCircle,
  Zap,
  FileText,
  Package,
  MessageSquare,
  AlertTriangle,
  Cpu,
  Loader2,
} from "lucide-react";

function formatTime(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  } catch {
    return iso;
  }
}

interface TimelineEntryConfig {
  icon: React.ElementType;
  iconClass: string;
  trackClass: string;
  label: (e: AnyWSEvent) => string;
  detail: (e: AnyWSEvent) => string | null;
  tag?: (e: AnyWSEvent) => string | null;
  tagClass?: string;
}

function getConfig(event: AnyWSEvent): TimelineEntryConfig {
  switch (event.event_type) {
    case EventType.WORKFLOW_STARTED:
      return {
        icon: Play,
        iconClass: "text-indigo-400 bg-indigo-500/10",
        trackClass: "border-indigo-500/30",
        label: () => "Workflow started",
        detail: (e) =>
          `Topic: ${(e as Extract<AnyWSEvent, { event_type: EventType.WORKFLOW_STARTED }>).topic} · ${(e as Extract<AnyWSEvent, { event_type: EventType.WORKFLOW_STARTED }>).total_agents} agents`,
        tag: () => "Started",
        tagClass: "bg-indigo-500/15 text-indigo-400",
      };
    case EventType.WORKFLOW_PROGRESS:
      return {
        icon: Loader2,
        iconClass: "text-amber-400 bg-amber-500/10",
        trackClass: "border-amber-500/20",
        label: (e) =>
          `${(e as Extract<AnyWSEvent, { event_type: EventType.WORKFLOW_PROGRESS }>).message}`,
        detail: (e) => {
          const ev = e as Extract<AnyWSEvent, { event_type: EventType.WORKFLOW_PROGRESS }>;
          return `${ev.percent_complete.toFixed(0)}% — agent ${ev.completed_agents}/${ev.total_agents}`;
        },
        tag: (e) =>
          `${(e as Extract<AnyWSEvent, { event_type: EventType.WORKFLOW_PROGRESS }>).percent_complete.toFixed(0)}%`,
        tagClass: "bg-amber-500/15 text-amber-400",
      };
    case EventType.WORKFLOW_COMPLETED:
      return {
        icon: CheckCircle2,
        iconClass: "text-emerald-400 bg-emerald-500/10",
        trackClass: "border-emerald-500/30",
        label: () => "Workflow completed",
        detail: (e) => {
          const ev = e as Extract<AnyWSEvent, { event_type: EventType.WORKFLOW_COMPLETED }>;
          return `${ev.duration_seconds.toFixed(1)}s · ${ev.papers_retrieved} papers · ${ev.sections_generated} sections · ${ev.tokens_used.toLocaleString()} tokens`;
        },
        tag: () => "Done",
        tagClass: "bg-emerald-500/15 text-emerald-400",
      };
    case EventType.WORKFLOW_FAILED:
      return {
        icon: XCircle,
        iconClass: "text-red-400 bg-red-500/10",
        trackClass: "border-red-500/30",
        label: () => "Workflow failed",
        detail: (e) => {
          const ev = e as Extract<AnyWSEvent, { event_type: EventType.WORKFLOW_FAILED }>;
          return `${ev.failed_agent}: ${ev.error_message}`;
        },
        tag: () => "Failed",
        tagClass: "bg-red-500/15 text-red-400",
      };
    case EventType.AGENT_STARTED:
      return {
        icon: Cpu,
        iconClass: "text-violet-400 bg-violet-500/10",
        trackClass: "border-violet-500/20",
        label: (e) =>
          `Agent: ${(e as Extract<AnyWSEvent, { event_type: EventType.AGENT_STARTED }>).agent_name}`,
        detail: (e) =>
          (e as Extract<AnyWSEvent, { event_type: EventType.AGENT_STARTED }>).agent_description,
        tag: () => "Running",
        tagClass: "bg-violet-500/15 text-violet-400",
      };
    case EventType.AGENT_COMPLETED:
      return {
        icon: CheckCircle2,
        iconClass: "text-emerald-400 bg-emerald-500/10",
        trackClass: "border-emerald-500/20",
        label: (e) =>
          `${(e as Extract<AnyWSEvent, { event_type: EventType.AGENT_COMPLETED }>).agent_name} completed`,
        detail: (e) => {
          const ev = e as Extract<AnyWSEvent, { event_type: EventType.AGENT_COMPLETED }>;
          return `${ev.duration_seconds.toFixed(1)}s · ${ev.tokens_used.toLocaleString()} tokens — ${ev.output_summary}`;
        },
        tag: (e) =>
          `+${(e as Extract<AnyWSEvent, { event_type: EventType.AGENT_COMPLETED }>).artifacts_produced.length} artifacts`,
        tagClass: "bg-emerald-500/15 text-emerald-400",
      };
    case EventType.AGENT_FAILED:
      return {
        icon: AlertTriangle,
        iconClass: "text-red-400 bg-red-500/10",
        trackClass: "border-red-500/20",
        label: (e) =>
          `${(e as Extract<AnyWSEvent, { event_type: EventType.AGENT_FAILED }>).agent_name} failed`,
        detail: (e) => {
          const ev = e as Extract<AnyWSEvent, { event_type: EventType.AGENT_FAILED }>;
          return `${ev.error_type}: ${ev.error_message}${ev.retrying ? " (retrying…)" : ""}`;
        },
        tag: () => "Error",
        tagClass: "bg-red-500/15 text-red-400",
      };
    case EventType.DRAFT_UPDATED:
      return {
        icon: FileText,
        iconClass: "text-sky-400 bg-sky-500/10",
        trackClass: "border-sky-500/20",
        label: (e) =>
          `Draft: ${(e as Extract<AnyWSEvent, { event_type: EventType.DRAFT_UPDATED }>).section_title}`,
        detail: (e) => {
          const ev = e as Extract<AnyWSEvent, { event_type: EventType.DRAFT_UPDATED }>;
          return ev.is_final
            ? `${ev.word_count.toLocaleString()} words — finalized`
            : `Streaming… ${ev.word_count.toLocaleString()} words`;
        },
        tag: (e) =>
          (e as Extract<AnyWSEvent, { event_type: EventType.DRAFT_UPDATED }>).is_final
            ? "Final"
            : "Streaming",
        tagClass: "bg-sky-500/15 text-sky-400",
      };
    case EventType.ARTIFACT_CREATED:
      return {
        icon: Package,
        iconClass: "text-teal-400 bg-teal-500/10",
        trackClass: "border-teal-500/20",
        label: (e) =>
          `Artifact: ${(e as Extract<AnyWSEvent, { event_type: EventType.ARTIFACT_CREATED }>).artifact_title}`,
        detail: (e) => {
          const ev = e as Extract<AnyWSEvent, { event_type: EventType.ARTIFACT_CREATED }>;
          return `${ev.artifact_type} · from ${ev.agent_source}`;
        },
        tag: (e) =>
          (e as Extract<AnyWSEvent, { event_type: EventType.ARTIFACT_CREATED }>).artifact_type,
        tagClass: "bg-teal-500/15 text-teal-400",
      };
    case EventType.COPILOT_MESSAGE:
      return {
        icon: MessageSquare,
        iconClass: "text-pink-400 bg-pink-500/10",
        trackClass: "border-pink-500/20",
        label: () => "Copilot response",
        detail: (e) => {
          const ev = e as Extract<AnyWSEvent, { event_type: EventType.COPILOT_MESSAGE }>;
          const preview = ev.content.slice(0, 120);
          return ev.content.length > 120 ? `${preview}…` : preview;
        },
        tag: (e) =>
          (e as Extract<AnyWSEvent, { event_type: EventType.COPILOT_MESSAGE }>).is_streaming
            ? "Streaming"
            : "Complete",
        tagClass: "bg-pink-500/15 text-pink-400",
      };
    default:
      return {
        icon: Zap,
        iconClass: "text-white/30 bg-white/5",
        trackClass: "border-white/10",
        label: (e) => e.event_type,
        detail: () => null,
      };
  }
}

const VISIBLE_TYPES = new Set<EventType>([
  EventType.WORKFLOW_STARTED,
  EventType.WORKFLOW_PROGRESS,
  EventType.WORKFLOW_COMPLETED,
  EventType.WORKFLOW_FAILED,
  EventType.AGENT_STARTED,
  EventType.AGENT_COMPLETED,
  EventType.AGENT_FAILED,
  EventType.DRAFT_UPDATED,
  EventType.ARTIFACT_CREATED,
  EventType.COPILOT_MESSAGE,
]);

function TimelineEntry({
  event,
  isLast,
}: {
  event: AnyWSEvent;
  isLast: boolean;
}) {
  const config = getConfig(event);
  const Icon = config.icon;
  const isProgress = event.event_type === EventType.WORKFLOW_PROGRESS;
  const label = config.label(event);
  const detail = config.detail(event);
  const tag = config.tag?.(event);

  return (
    <li className="relative flex gap-3 pb-4 last:pb-0">
      {/* Track line */}
      {!isLast && (
        <div
          className={cn(
            "absolute left-4 top-8 bottom-0 w-px border-l border-dashed",
            config.trackClass
          )}
        />
      )}

      {/* Icon */}
      <div
        className={cn(
          "relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-white/10",
          config.iconClass,
          isProgress && "opacity-60"
        )}
      >
        <Icon
          className={cn(
            "h-3.5 w-3.5",
            event.event_type === EventType.AGENT_STARTED && "animate-pulse",
            (event.event_type === EventType.WORKFLOW_PROGRESS) &&
              "animate-spin"
          )}
        />
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0 pt-1">
        <div className="flex items-start justify-between gap-2">
          <p
            className={cn(
              "text-sm font-medium text-white leading-tight",
              isProgress && "text-white/60 font-normal"
            )}
          >
            {label}
          </p>
          <div className="flex items-center gap-1.5 shrink-0">
            {tag && (
              <span
                className={cn(
                  "text-[10px] font-medium px-1.5 py-0.5 rounded-full",
                  config.tagClass
                )}
              >
                {tag}
              </span>
            )}
            <span className="text-[10px] text-white/25 font-mono tabular-nums whitespace-nowrap">
              {formatTime(event.timestamp)}
            </span>
          </div>
        </div>
        {detail && (
          <p
            className={cn(
              "mt-0.5 text-xs leading-relaxed",
              isProgress ? "text-white/35" : "text-white/50"
            )}
          >
            {detail}
          </p>
        )}
      </div>
    </li>
  );
}

interface WorkflowTimelineProps {
  className?: string;
  autoScroll?: boolean;
  maxHeight?: string;
  filterProgress?: boolean;
}

export function WorkflowTimeline({
  className,
  autoScroll = true,
  maxHeight = "480px",
  filterProgress = false,
}: WorkflowTimelineProps) {
  const events = useWebSocketStore((s) => s.events);
  const workflowStatus = useWebSocketStore((s) => s.workflowStatus);
  const clearEvents = useWebSocketStore((s) => s.clearEvents);
  const bottomRef = useRef<HTMLDivElement>(null);

  const visible = events.filter((e) => {
    if (!VISIBLE_TYPES.has(e.event_type as EventType)) return false;
    if (filterProgress && e.event_type === EventType.WORKFLOW_PROGRESS)
      return false;
    return true;
  });

  useEffect(() => {
    if (autoScroll && bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: "smooth", block: "end" });
    }
  }, [visible.length, autoScroll]);

  if (workflowStatus === "idle" && visible.length === 0) return null;

  return (
    <div
      className={cn(
        "rounded-xl border border-white/10 bg-white/2 flex flex-col overflow-hidden",
        className
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/8 bg-white/3 shrink-0">
        <div className="flex items-center gap-2">
          <Zap className="h-3.5 w-3.5 text-indigo-400" />
          <span className="text-xs font-semibold text-white/70 uppercase tracking-widest">
            Live Timeline
          </span>
          {visible.length > 0 && (
            <span className="text-[10px] text-white/30 font-mono">
              {visible.length} events
            </span>
          )}
        </div>
        {visible.length > 0 && (
          <button
            onClick={clearEvents}
            className="text-[10px] text-white/30 hover:text-white/60 transition-colors"
          >
            Clear
          </button>
        )}
      </div>

      {/* Timeline */}
      <div
        className="overflow-y-auto px-4 py-4"
        style={{ maxHeight }}
      >
        {visible.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-10 text-center">
            <Loader2 className="h-6 w-6 text-white/20 animate-spin mb-3" />
            <p className="text-sm text-white/30">Waiting for workflow events…</p>
          </div>
        ) : (
          <ul className="space-y-0">
            {visible.map((event, i) => (
              <TimelineEntry
                key={event.event_id}
                event={event}
                isLast={i === visible.length - 1}
              />
            ))}
          </ul>
        )}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}
