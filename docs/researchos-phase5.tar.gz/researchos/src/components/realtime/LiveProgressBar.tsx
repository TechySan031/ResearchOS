"use client";

import { useWebSocketStore } from "@/stores/websocketStore";
import { cn } from "@/lib/utils";
import { CheckCircle2, XCircle, Loader2, Clock } from "lucide-react";

interface LiveProgressBarProps {
  className?: string;
  showDetails?: boolean;
}

export function LiveProgressBar({
  className,
  showDetails = true,
}: LiveProgressBarProps) {
  const workflowStatus = useWebSocketStore((s) => s.workflowStatus);
  const progress = useWebSocketStore((s) => s.progress);
  const progressMessage = useWebSocketStore((s) => s.progressMessage);
  const completedAgents = useWebSocketStore((s) => s.completedAgents);
  const totalAgents = useWebSocketStore((s) => s.totalAgents);
  const currentAgent = useWebSocketStore((s) => s.currentAgent);

  if (workflowStatus === "idle") return null;

  const barColor =
    workflowStatus === "completed"
      ? "bg-emerald-500"
      : workflowStatus === "failed"
      ? "bg-red-500"
      : "bg-indigo-500";

  const StatusIcon = () => {
    if (workflowStatus === "completed")
      return <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />;
    if (workflowStatus === "failed")
      return <XCircle className="h-4 w-4 text-red-500 shrink-0" />;
    return (
      <Loader2 className="h-4 w-4 animate-spin text-indigo-500 shrink-0" />
    );
  };

  return (
    <div
      className={cn(
        "w-full rounded-xl border border-white/10 bg-white/3 p-4 space-y-3",
        className
      )}
    >
      {/* Header row */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 min-w-0">
          <StatusIcon />
          <span className="text-sm font-medium text-white truncate">
            {workflowStatus === "completed"
              ? "Workflow complete"
              : workflowStatus === "failed"
              ? "Workflow failed"
              : currentAgent?.name
              ? `Running: ${currentAgent.name}`
              : "Workflow running…"}
          </span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {totalAgents > 0 && (
            <span className="text-xs text-white/40 font-mono tabular-nums">
              {completedAgents}/{totalAgents}
            </span>
          )}
          <span
            className={cn(
              "text-sm font-bold font-mono tabular-nums",
              workflowStatus === "completed"
                ? "text-emerald-400"
                : workflowStatus === "failed"
                ? "text-red-400"
                : "text-indigo-400"
            )}
          >
            {progress.toFixed(0)}%
          </span>
        </div>
      </div>

      {/* Progress track */}
      <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
        <div
          className={cn(
            "h-full rounded-full transition-all duration-500 ease-out",
            barColor,
            workflowStatus === "running" &&
              progress < 100 &&
              "relative after:absolute after:inset-0 after:translate-x-[-100%] after:animate-shimmer after:bg-gradient-to-r after:from-transparent after:via-white/20 after:to-transparent"
          )}
          style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
        />
      </div>

      {/* Detail row */}
      {showDetails && progressMessage && (
        <p className="text-xs text-white/50 leading-relaxed truncate">
          {progressMessage}
        </p>
      )}

      {/* Agent steps */}
      {showDetails && totalAgents > 0 && (
        <div className="flex items-center gap-1 flex-wrap">
          {Array.from({ length: totalAgents }).map((_, i) => (
            <div
              key={i}
              className={cn(
                "h-1 flex-1 min-w-[16px] rounded-full transition-colors duration-300",
                i < completedAgents
                  ? workflowStatus === "failed" && i === completedAgents - 1
                    ? "bg-red-500"
                    : "bg-emerald-500"
                  : i === completedAgents && workflowStatus === "running"
                  ? "bg-indigo-400 animate-pulse"
                  : "bg-white/10"
              )}
            />
          ))}
        </div>
      )}
    </div>
  );
}
