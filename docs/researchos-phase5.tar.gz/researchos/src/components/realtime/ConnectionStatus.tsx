"use client";

import { useWebSocketStore } from "@/stores/websocketStore";
import type { ConnectionState } from "@/lib/websocket";
import { cn } from "@/lib/utils";
import { Wifi, WifiOff, Loader2, AlertCircle } from "lucide-react";

const STATE_CONFIG: Record<
  ConnectionState,
  {
    label: string;
    icon: React.ElementType;
    dotClass: string;
    textClass: string;
    bgClass: string;
    borderClass: string;
    animate: boolean;
  }
> = {
  connected: {
    label: "Connected",
    icon: Wifi,
    dotClass: "bg-emerald-500",
    textClass: "text-emerald-700 dark:text-emerald-400",
    bgClass: "bg-emerald-50 dark:bg-emerald-500/10",
    borderClass: "border-emerald-200 dark:border-emerald-500/20",
    animate: true,
  },
  connecting: {
    label: "Connecting",
    icon: Loader2,
    dotClass: "bg-amber-500",
    textClass: "text-amber-700 dark:text-amber-400",
    bgClass: "bg-amber-50 dark:bg-amber-500/10",
    borderClass: "border-amber-200 dark:border-amber-500/20",
    animate: false,
  },
  reconnecting: {
    label: "Reconnecting",
    icon: Loader2,
    dotClass: "bg-amber-500",
    textClass: "text-amber-700 dark:text-amber-400",
    bgClass: "bg-amber-50 dark:bg-amber-500/10",
    borderClass: "border-amber-200 dark:border-amber-500/20",
    animate: false,
  },
  disconnected: {
    label: "Disconnected",
    icon: WifiOff,
    dotClass: "bg-slate-400",
    textClass: "text-slate-600 dark:text-slate-400",
    bgClass: "bg-slate-50 dark:bg-slate-500/10",
    borderClass: "border-slate-200 dark:border-slate-500/20",
    animate: false,
  },
};

interface ConnectionStatusProps {
  compact?: boolean;
  className?: string;
}

export function ConnectionStatus({
  compact = false,
  className,
}: ConnectionStatusProps) {
  const connectionState = useWebSocketStore((s) => s.connectionState);
  const config = STATE_CONFIG[connectionState];
  const Icon = config.icon;
  const isSpinning =
    connectionState === "connecting" || connectionState === "reconnecting";

  if (compact) {
    return (
      <div
        className={cn("flex items-center gap-1.5", className)}
        title={config.label}
      >
        <span className="relative flex h-2 w-2">
          {config.animate && (
            <span
              className={cn(
                "absolute inline-flex h-full w-full animate-ping rounded-full opacity-75",
                config.dotClass
              )}
            />
          )}
          <span
            className={cn(
              "relative inline-flex h-2 w-2 rounded-full",
              config.dotClass
            )}
          />
        </span>
        <span className={cn("text-xs font-medium", config.textClass)}>
          {config.label}
        </span>
      </div>
    );
  }

  return (
    <div
      className={cn(
        "inline-flex items-center gap-2 rounded-lg border px-3 py-1.5 text-sm font-medium transition-colors",
        config.bgClass,
        config.borderClass,
        config.textClass,
        className
      )}
    >
      <span className="relative flex h-2 w-2 shrink-0">
        {config.animate && (
          <span
            className={cn(
              "absolute inline-flex h-full w-full animate-ping rounded-full opacity-75",
              config.dotClass
            )}
          />
        )}
        <span
          className={cn(
            "relative inline-flex h-2 w-2 rounded-full",
            config.dotClass
          )}
        />
      </span>
      <Icon
        className={cn("h-3.5 w-3.5 shrink-0", isSpinning && "animate-spin")}
      />
      <span>{config.label}</span>
    </div>
  );
}
