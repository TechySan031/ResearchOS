from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from app.db.redis import get_redis, publish_event
from app.websockets.connection_manager import manager
from app.websockets.events import AnyEvent, EventType

logger = logging.getLogger(__name__)

CHANNEL_PREFIX_PROJECT = "ws:project:"
CHANNEL_PREFIX_COPILOT = "ws:copilot:"
CHANNEL_GLOBAL = "ws:global"


def _project_channel(project_id: str) -> str:
    return f"{CHANNEL_PREFIX_PROJECT}{project_id}"


def _copilot_channel(project_id: str) -> str:
    return f"{CHANNEL_PREFIX_COPILOT}{project_id}"


async def publish_to_project(project_id: str, event: AnyEvent) -> None:
    payload = event.to_ws_payload()
    channel = _project_channel(project_id)
    await publish_event(channel, payload)


async def publish_to_copilot(project_id: str, event: AnyEvent) -> None:
    payload = event.to_ws_payload()
    channel = _copilot_channel(project_id)
    await publish_event(channel, payload)


async def publish_global(event: AnyEvent) -> None:
    payload = event.to_ws_payload()
    await publish_event(CHANNEL_GLOBAL, payload)


class RedisSubscriberTask:
    def __init__(self) -> None:
        self._task: asyncio.Task[None] | None = None
        self._running = False

    async def start(self) -> None:
        self._running = True
        self._task = asyncio.create_task(self._run(), name="redis-ws-subscriber")
        logger.info("Redis WebSocket subscriber started")

    async def stop(self) -> None:
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("Redis WebSocket subscriber stopped")

    async def _run(self) -> None:
        while self._running:
            try:
                await self._subscribe_loop()
            except Exception as exc:
                logger.error("Subscriber loop crashed: %s — restarting in 2s", exc)
                await asyncio.sleep(2)

    async def _subscribe_loop(self) -> None:
        redis = await get_redis()
        pubsub = redis.pubsub()
        try:
            await pubsub.psubscribe(
                f"{CHANNEL_PREFIX_PROJECT}*",
                f"{CHANNEL_PREFIX_COPILOT}*",
                CHANNEL_GLOBAL,
            )
            async for raw_message in pubsub.listen():
                if not self._running:
                    break
                if raw_message["type"] not in ("message", "pmessage"):
                    continue
                await self._dispatch(raw_message)
        finally:
            await pubsub.unsubscribe()
            await pubsub.punsubscribe()
            await pubsub.aclose()

    async def _dispatch(self, raw_message: dict[str, Any]) -> None:
        try:
            channel: str = raw_message.get("channel") or ""
            data_raw = raw_message.get("data", "")
            if isinstance(data_raw, bytes):
                data_raw = data_raw.decode()
            payload: dict[str, Any] = json.loads(data_raw)
            project_id: str = payload.get("project_id", "")

            if channel == CHANNEL_GLOBAL:
                await manager.broadcast_all(payload)
            elif channel.startswith(CHANNEL_PREFIX_PROJECT) and project_id:
                await manager.broadcast_to_project(project_id, payload)
            elif channel.startswith(CHANNEL_PREFIX_COPILOT) and project_id:
                await manager.broadcast_to_project(project_id, payload)
        except Exception as exc:
            logger.warning("Failed to dispatch WS message: %s", exc)


broadcaster_task = RedisSubscriberTask()
