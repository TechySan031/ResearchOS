from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect, status
from jose import JWTError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import verify_access_token
from app.db.base import AsyncSessionLocal
from app.models.user import User
from app.websockets.connection_manager import manager
from app.websockets.events import (
    ConnectionAckEvent,
    ErrorEvent,
    EventType,
    PongEvent,
)

logger = logging.getLogger(__name__)
router = APIRouter(tags=["websocket"])

HEARTBEAT_INTERVAL = 30
CLIENT_TIMEOUT = 90


async def _authenticate_ws(token: str) -> User | None:
    try:
        user_id = verify_access_token(token)
    except JWTError:
        return None
    async with AsyncSessionLocal() as db:
        result = await db.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        if user and user.is_active:
            return user
    return None


async def _heartbeat(websocket: WebSocket, conn_id: str) -> None:
    while True:
        await asyncio.sleep(HEARTBEAT_INTERVAL)
        try:
            await websocket.send_json({"event_type": EventType.PING, "conn_id": conn_id})
        except Exception:
            break


async def _handle_client_message(
    raw: str | bytes,
    websocket: WebSocket,
    conn_id: str,
    project_id: str,
) -> None:
    try:
        data: dict[str, Any] = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return

    event_type = data.get("event_type")
    if event_type == EventType.PONG:
        return
    if event_type == EventType.PING:
        pong = PongEvent(project_id=project_id)
        try:
            await websocket.send_json(pong.to_ws_payload())
        except Exception:
            pass


@router.websocket("/ws/projects/{project_id}")
async def project_websocket(
    websocket: WebSocket,
    project_id: str,
    token: str = Query(...),
) -> None:
    user = await _authenticate_ws(token)
    if user is None:
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
        return

    conn = await manager.connect(websocket, project_id=project_id, user_id=user.id)

    ack = ConnectionAckEvent(
        project_id=project_id,
        connection_id=conn.id,
        user_id=user.id,
        subscribed_to=f"project:{project_id}",
    )
    await websocket.send_json(ack.to_ws_payload())

    heartbeat_task = asyncio.create_task(
        _heartbeat(websocket, conn.id),
        name=f"heartbeat-{conn.id}",
    )

    try:
        while True:
            try:
                raw = await asyncio.wait_for(
                    websocket.receive_text(),
                    timeout=CLIENT_TIMEOUT,
                )
                await _handle_client_message(raw, websocket, conn.id, project_id)
            except asyncio.TimeoutError:
                err = ErrorEvent(
                    project_id=project_id,
                    code="connection_timeout",
                    message="No message received within timeout period",
                    recoverable=True,
                )
                try:
                    await websocket.send_json(err.to_ws_payload())
                    await websocket.close()
                except Exception:
                    pass
                break
    except WebSocketDisconnect:
        logger.info("Client disconnected: conn_id=%s", conn.id)
    except Exception as exc:
        logger.error("WebSocket error: conn_id=%s error=%s", conn.id, exc)
    finally:
        heartbeat_task.cancel()
        await manager.disconnect(conn.id)
