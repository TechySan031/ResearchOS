from __future__ import annotations

import time
from typing import Any

from app.websockets.broadcaster import publish_to_copilot, publish_to_project
from app.websockets.events import (
    AgentCompletedEvent,
    AgentFailedEvent,
    AgentStartedEvent,
    ArtifactCreatedEvent,
    CopilotMessageEvent,
    DraftUpdatedEvent,
    WorkflowCompletedEvent,
    WorkflowFailedEvent,
    WorkflowProgressEvent,
    WorkflowStartedEvent,
)


class EventService:
    def __init__(self, project_id: str) -> None:
        self.project_id = project_id

    async def workflow_started(
        self,
        topic: str,
        total_agents: int,
        initiated_by: str,
    ) -> None:
        await publish_to_project(
            self.project_id,
            WorkflowStartedEvent(
                project_id=self.project_id,
                topic=topic,
                total_agents=total_agents,
                initiated_by=initiated_by,
            ),
        )

    async def workflow_progress(
        self,
        current_agent: str,
        completed_agents: int,
        total_agents: int,
        message: str,
    ) -> None:
        percent = (completed_agents / max(total_agents, 1)) * 100.0
        await publish_to_project(
            self.project_id,
            WorkflowProgressEvent(
                project_id=self.project_id,
                current_agent=current_agent,
                completed_agents=completed_agents,
                total_agents=total_agents,
                percent_complete=round(percent, 2),
                message=message,
            ),
        )

    async def workflow_completed(
        self,
        duration_seconds: float,
        papers_retrieved: int,
        sections_generated: int,
        tokens_used: int,
    ) -> None:
        await publish_to_project(
            self.project_id,
            WorkflowCompletedEvent(
                project_id=self.project_id,
                duration_seconds=round(duration_seconds, 3),
                papers_retrieved=papers_retrieved,
                sections_generated=sections_generated,
                tokens_used=tokens_used,
            ),
        )

    async def workflow_failed(
        self,
        failed_agent: str,
        error_message: str,
        retry_possible: bool = True,
    ) -> None:
        await publish_to_project(
            self.project_id,
            WorkflowFailedEvent(
                project_id=self.project_id,
                failed_agent=failed_agent,
                error_message=error_message,
                retry_possible=retry_possible,
            ),
        )

    async def agent_started(
        self,
        agent_name: str,
        agent_description: str,
        agent_index: int,
        total_agents: int,
    ) -> None:
        await publish_to_project(
            self.project_id,
            AgentStartedEvent(
                project_id=self.project_id,
                agent_name=agent_name,
                agent_description=agent_description,
                agent_index=agent_index,
                total_agents=total_agents,
            ),
        )

    async def agent_completed(
        self,
        agent_name: str,
        duration_seconds: float,
        tokens_used: int,
        output_summary: str,
        artifacts_produced: list[str] | None = None,
    ) -> None:
        await publish_to_project(
            self.project_id,
            AgentCompletedEvent(
                project_id=self.project_id,
                agent_name=agent_name,
                duration_seconds=round(duration_seconds, 3),
                tokens_used=tokens_used,
                output_summary=output_summary,
                artifacts_produced=artifacts_produced or [],
            ),
        )

    async def agent_failed(
        self,
        agent_name: str,
        error_message: str,
        error_type: str,
        duration_seconds: float,
        retrying: bool = False,
    ) -> None:
        await publish_to_project(
            self.project_id,
            AgentFailedEvent(
                project_id=self.project_id,
                agent_name=agent_name,
                error_message=error_message,
                error_type=error_type,
                duration_seconds=round(duration_seconds, 3),
                retrying=retrying,
            ),
        )

    async def draft_updated(
        self,
        section_id: str,
        section_title: str,
        content_chunk: str,
        is_final: bool,
        word_count: int,
    ) -> None:
        await publish_to_project(
            self.project_id,
            DraftUpdatedEvent(
                project_id=self.project_id,
                section_id=section_id,
                section_title=section_title,
                content_chunk=content_chunk,
                is_final=is_final,
                word_count=word_count,
            ),
        )

    async def artifact_created(
        self,
        artifact_type: str,
        artifact_id: str,
        artifact_title: str,
        agent_source: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        await publish_to_project(
            self.project_id,
            ArtifactCreatedEvent(
                project_id=self.project_id,
                artifact_type=artifact_type,
                artifact_id=artifact_id,
                artifact_title=artifact_title,
                agent_source=agent_source,
                metadata=metadata or {},
            ),
        )

    async def copilot_message(
        self,
        message_id: str,
        content: str,
        is_streaming: bool,
        is_final: bool,
        context_sources: list[str] | None = None,
    ) -> None:
        await publish_to_copilot(
            self.project_id,
            CopilotMessageEvent(
                project_id=self.project_id,
                message_id=message_id,
                role="assistant",
                content=content,
                is_streaming=is_streaming,
                is_final=is_final,
                context_sources=context_sources or [],
            ),
        )
